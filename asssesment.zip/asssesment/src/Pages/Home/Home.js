import React from 'react';
import { Switch, Route } from 'react-router-dom'
import Header from '../../Components/Header/Header';
import Header2 from '../NewHome/Header2';
import NewHome from '../NewHome/NewHome';
import Profile from '../Profile/Profile';
const Home = ({ handleLogged }) => {
    return ( < div >
        <Header isLogged = { handleLogged }/>
         < Switch >
        <Route exact path = '/'
        component = { NewHome } /> 
        < Route path = '/:username'
        component = { Profile } /> 
        <Route exact path ='/'
        component = {Header2}/></Switch></div>
    )
}

export default Home;