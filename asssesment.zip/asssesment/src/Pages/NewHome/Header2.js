import React from 'react';
import Header from '../../Components/Header/Header';


function Header2(){
    return(
        <div className="maincontainer">
         <h1>Create Trade Idea</h1>
         
         <div class="container">
             
 
               <div class="card bg-light">
               <article class="card-body mx-auto" style={{maxWidth: "400px"}}>
                    <form>
                    <div class="form-group input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                        </div>
                        <input name="" class="form-control" placeholder="Full name" type="text" />
                    </div> 
                    <div class="form-group input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
                        </div>
                        <input name="" class="form-control" placeholder="Email address" type="email" />
                    </div>
                    <div class="form-group input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                        </div>
                        <input class="form-control" placeholder="Create password" type="password" />
                    </div> 
                    <div class="form-group input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                        </div>
                        <input class="form-control" placeholder="Repeat password" type="password" />
                    </div>                                       
                    <div class="form-group">
                    <button type="button" class="btn"> Cancel  </button>
                    <button className = "btn" > Create</button>
                    
                    </div>                                                                    
                </form>
                </article>
                </div> 
                
                </div> 
             
        </div>
    )
}



export default Header2;