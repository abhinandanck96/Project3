import React from 'react';
import './newhome.css';
import { CCard } from '@coreui/react';
import { CCardImageOverlay} from '@coreui/react';
import { CCardTitle } from '@coreui/react';
import { CCardImage } from '@coreui/react';
import { CCardText } from '@coreui/react';



const NewHome = () => {
    return (
         <div className = 'div-newhome' >
  <CCard className=" CCard mb-3 bg-dark text-white">
    <CCardTitle style={{fontSize: '30px'}}>Bitcoin will go up
    <button className="submit" type="button" ><a href="https://iqbroker.co/lp/mob
    ile/en/?aff=97642&afftrack=GAD_IN_EN_00_FTD_All_Web_13984335100_c_124612796306_kwd-11077776&gclid=Cj0KCQiA4b2MBhD2ARIsAIrcB-RfGTKUuBr6-xGRUREVml2xvL8vFV1Pa9TUiAEdJdmQDt3k2VSHKLMaAjEyEALw_wcB">Join this Idea</a></button>
    <br /><p1 className="w">for $BTC/USDT</p1></CCardTitle>
     
    <CCardText style={{backgroundColor: 'red',width:'8%',Color:'white', border: '2px solid red',borderRadius:'25px'}}>
      High Risk
    </CCardText>
    <CCardText>
      Enter below<span className="dollar">$8500</span>
    </CCardText>
    <CCardText>
      Book profit near<span className="dollar1">$10000-$12000</span>
    </CCardText>
    <CCardText>Stoploss at<span className="dollar">$8000</span></CCardText>
</CCard>
        </div>
    )
}

export default NewHome;