import React from 'react';
import { NavLink, withRouter } from 'react-router-dom'
import { ReactComponent as Home } from '../../assets/home.svg';
import { ReactComponent as Explore } from '../../assets/explore.svg';
import './header.css';
const Header = ({ history, isLogged }) => {
    const handleClick = () => {
        history.push('/')
        isLogged(false)
    }
    return ( <nav >
        <div className = 'div-header' >
        <div className = 'div-svg'
        onClick = {
            () => history.push('/') } >
        <button className = 'button-header'
        onClick = { handleClick } > Log out </button> 
        </div> 
        </div>
        <div className='Card'>
            <h1>Hi Abhi</h1>

            
        </div>
</nav>

    )
}

export default withRouter(Header);